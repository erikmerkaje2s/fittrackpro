import React from "react";
import FitTrackPro from "./FitTrackPro";

export default function App() {
  return <FitTrackPro />;
}
